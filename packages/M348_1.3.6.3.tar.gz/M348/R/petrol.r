#' Petrol pump efficiency
#'
#' In a study of petrol pump efficiency, a group of scientists measured the
#' amount of hydrocarbon emitted during refuelling on 125 occasions. They
#' want to find out if hydrocarbon emissions are affected by the conditions at
#' which refuelling takes place (and could thus be reduced in the future).
#'
#' @format A data frame with 125 rows and 5 variables:
#' \describe{
#'   \item{loghcarb}{log of the amount of hydrocarbon emitted (grams)}
#'   \item{tanktemp}{initial tank temperature ( degrees F)}
#'   \item{disptemp}{temperature of the dispensed petrol ( degrees F)}
#'   \item{tankpres}{initial vapour pressure (psi)}
#'   \item{disppres}{vapour pressure of the dispensed petrol (psi)}
#' }
#'
#' @usage data(petrol)

"petrol"
