#' Data from an MMSE study 
#'
#' The data from a simulated MMSE study which used estimates from real MMSE studies. In this study the MMSE score was
#' simulated for 1000 (fictional) participants of different ages, genders and
#' education levels, all of whom were assumed not to have been previously
#' diagnosed with dementia.
#' @format A data frame with 1000 rows and 4 variables:
#' \describe{
#'   \item{mmse}{the participant's MMSE score}
#'   \item{age}{the participant's age (in years)}
#'   \item{gender}{the gender that the participant identifies with, taking the coded values 0 (for male) and 1 (for female)}
#'   \item{edu}{the participant's level of education,}
#' }
#'
#' @usage data(mmseData)

"mmseData"
