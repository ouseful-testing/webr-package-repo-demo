#' A function to calculate the second derivative of a log-likelihood
#'
#' @param p the binomial probability
#' @param n the total number of observations
#' @param sy the number of successes
#'
#' @return the value of the second derviative
#'
#' @author Karen Vines
#' 
#' @export


lDoubleDash <- function(p, n=n, sy=sy){
	value <- -sy/(p^2) - (n-sy)/(1-p)^2
	value
}
