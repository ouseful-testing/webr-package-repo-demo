#' Airway devices and sore throats
#'
#' The aim of a study carried out in 2004 at the Royal Berkshire Hospital,
#' Reading, was to investigate the incidence of sore throats in patients who had
#' undergone surgery. Of particular interest was whether the occurrence of a
#' sore throat was affected by the method used to deliver anaesthetic gas, as
#' one of three types of airway device was used on each patient.
#'
#' @format A data frame with 125 rows and 6 variables:
#' \describe{
#'   \item{age}{the patient's age (in years)}
#'   \item{gender}{the gender the patient identifies with, taking the values 0 (for male) and 1 (for female)}
#'   \item{logDuration}{log of the duration of the operation (in minutes)}
#'   \item{method}{the type of airway device used}
#'   \item{lubricated}{if lubrication used when inserting airway device, taking the values 0 (for no) and 1 (for yes)}
#'   \item{sore}{occurrence of sore throat after surgery, taking the values 0 (for no) and 1 (for yes).}
#' }
#'
#' @usage data(soreThroat)

"soreThroat"
