#' Data from a (fictional) cricket league
#'
#' Data from a (fictional) cricket league, where 160 players provided their respective batting and bowling averages from their last T20 season.
#'
#' @format A data frame with 160 rows and 2 variables:
#' \describe{
#'   \item{batAve}{a player's batting average}
#'   \item{bowlAve}{a player's bowling average}
#' }
#'
#' @usage data(cricket)

"cricket"
