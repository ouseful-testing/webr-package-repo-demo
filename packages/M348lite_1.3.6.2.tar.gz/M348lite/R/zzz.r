.onLoad <- function(libname, pkgname){
	initialise()
}
