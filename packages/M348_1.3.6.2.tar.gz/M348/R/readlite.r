#' A function to read .csv files wherever they are in the Jupyterlite environment
#'
#' @param filename the name of the file to be read in
#'
#' @return a data frame containing the contents of the file
#'
#' @author Karen Vines
#' 
#' @export


read.csv <- function(filename){
	if (!file.exists(filename)){
		if (!exists("PORTNUMBER")){
			errMess <- c("PORTNUMBER has not yet been defined. Suggest setting it using the command `initialise(PORTNUMBER = 8348)'.\n")
			stop(errMess)
		} else {
			filename <- paste("http://localhost:",PORTNUMBER,"/files/",filename, sep="")
		}
	}
	utils::read.csv(filename)
}